package com.joaobrandao.alura_musica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AluraMusicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AluraMusicaApplication.class, args);
	}

}
